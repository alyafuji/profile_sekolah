"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
} from "motion/react";
import { sekolah } from "@/data/sekolah";

const kataKunci = ["Mulia", "Kompeten", "Peduli Lingkungan"];
const kataJudul = sekolah.nama.split(" ");

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });

  // parallax: tiap lapisan bergerak dengan kecepatan berbeda saat di-scroll
  const yBlobA = useTransform(scrollYProgress, [0, 1], [0, 180]);
  const yBlobB = useTransform(scrollYProgress, [0, 1], [0, -120]);
  const ySkyline = useTransform(scrollYProgress, [0, 1], [0, 90]);
  const yKonten = useTransform(scrollYProgress, [0, 1], [0, 70]);
  const opKonten = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  // logo miring mengikuti kursor
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rotX = useSpring(useTransform(my, [-1, 1], [14, -14]), { stiffness: 140, damping: 14 });
  const rotY = useSpring(useTransform(mx, [-1, 1], [-14, 14]), { stiffness: 140, damping: 14 });

  function gerak(e) {
    const r = e.currentTarget.getBoundingClientRect();
    mx.set(((e.clientX - r.left) / r.width - 0.5) * 2);
    my.set(((e.clientY - r.top) / r.height - 0.5) * 2);
  }
  function lepas() {
    mx.set(0);
    my.set(0);
  }

  // kata kunci slogan berganti otomatis
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx((v) => (v + 1) % kataKunci.length), 2500);
    return () => clearInterval(t);
  }, []);

  return (
    <section
      ref={ref}
      className="relative isolate flex min-h-[100svh] items-center overflow-hidden bg-gradient-to-br from-ocean-950 via-ocean-900 to-ocean-800 text-white"
    >
      <div className="pola-titik absolute inset-0 -z-10 opacity-60" />

      <motion.div
        aria-hidden
        style={{ y: yBlobA }}
        className="absolute -left-24 top-10 -z-10 h-96 w-96 rounded-full bg-aqua-400/30 blur-3xl"
      />
      <motion.div
        aria-hidden
        style={{ y: yBlobB }}
        className="absolute -right-24 bottom-24 -z-10 h-[28rem] w-[28rem] rounded-full bg-ocean-500/40 blur-3xl"
      />

      {/* siluet sekolah di bagian bawah (parallax) */}
      <motion.div
        aria-hidden
        style={{ y: ySkyline }}
        className="absolute inset-x-0 bottom-0 -z-10 h-48 md:h-72"
      >
        <Image src="/banner.svg" alt="" fill unoptimized priority className="object-cover object-bottom opacity-60" />
      </motion.div>

      <motion.div
        style={{ y: yKonten, opacity: opKonten }}
        className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 pb-32 pt-32 md:grid-cols-5"
      >
        <div className="md:col-span-3">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 py-1.5 text-sm font-semibold backdrop-blur"
          >
            <span className="h-2 w-2 animate-pulse rounded-full bg-aqua-400" />
            Sejak {sekolah.bulanBerdiri} {sekolah.tahunBerdiri} · {sekolah.julukan}
          </motion.p>

          <h1 className="mt-6 font-display text-5xl font-extrabold leading-[1.05] md:text-7xl">
            {kataJudul.map((kata, i) => (
              <span key={i} className="mr-3 inline-block overflow-hidden align-bottom">
                <motion.span
                  className="inline-block"
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                >
                  {kata}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-6 text-xl text-white/85 md:text-2xl"
          >
            Generasi yang{" "}
            <span className="relative inline-block min-w-[9ch] align-bottom font-bold text-sun">
              <AnimatePresence mode="wait">
                <motion.span
                  key={kataKunci[idx]}
                  className="inline-block"
                  initial={{ y: 24, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -24, opacity: 0 }}
                  transition={{ duration: 0.35 }}
                >
                  {kataKunci[idx]}
                </motion.span>
              </AnimatePresence>
            </span>
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-3 max-w-lg text-white/65"
          >
            {sekolah.tagline}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.15 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link
                href="/about"
                className="block rounded-full bg-sun px-7 py-3.5 font-bold text-ocean-950 shadow-lg shadow-sun/20"
              >
                Kenali Sekolah Kami
              </Link>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link
                href="/berita"
                className="block rounded-full border-2 border-white/60 px-7 py-3 font-bold text-white transition-colors hover:bg-white hover:text-ocean-900"
              >
                Baca Berita
              </Link>
            </motion.div>
          </motion.div>
        </div>

        {/* logo 3D interaktif */}
        <div className="md:col-span-2" onMouseMove={gerak} onMouseLeave={lepas}>
          <div className="relative mx-auto flex h-72 w-72 items-center justify-center md:h-96 md:w-96">
            <motion.div
              aria-hidden
              className="absolute inset-0 rounded-full border-2 border-dashed border-aqua-400/50"
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            />
            <motion.div
              aria-hidden
              className="absolute inset-6 rounded-full border border-white/20"
              animate={{ rotate: -360 }}
              transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
            />
            <div aria-hidden className="absolute inset-12 rounded-full bg-aqua-400/20 blur-2xl" />

            <motion.div
              style={{ rotateX: rotX, rotateY: rotY, transformPerspective: 900 }}
              initial={{ scale: 0, rotate: -30, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 120, damping: 14, delay: 0.4 }}
              className="relative"
            >
              <motion.div
                animate={{ y: [0, -14, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <Image
                  src="/logo.png"
                  alt={`Logo ${sekolah.nama}`}
                  width={240}
                  height={240}
                  priority
                  className="h-44 w-44 drop-shadow-2xl md:h-60 md:w-60"
                />
              </motion.div>
            </motion.div>

            <motion.span
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -right-2 top-8 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-ocean-900 shadow-lg"
            >
              Adiwiyata
            </motion.span>
            <motion.span
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 4.2, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -left-4 bottom-12 rounded-full bg-aqua-400 px-3 py-1.5 text-xs font-bold text-ocean-950 shadow-lg"
            >
              {sekolah.motto}
            </motion.span>
          </div>
        </div>
      </motion.div>

      {/* gelombang penutup */}
      <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 1440 90" preserveAspectRatio="none" aria-hidden>
        <motion.path
          fill="#eaf8fb"
          animate={{
            d: [
              "M0 50 C240 90 480 10 720 50 C960 90 1200 20 1440 50 V90 H0 Z",
              "M0 60 C240 20 480 90 720 55 C960 20 1200 80 1440 55 V90 H0 Z",
              "M0 50 C240 90 480 10 720 50 C960 90 1200 20 1440 50 V90 H0 Z",
            ],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
      </svg>
    </section>
  );
}
