"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "motion/react";
import { sekolah } from "@/data/sekolah";

const menu = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/berita", label: "Berita" },
  { href: "/kontak", label: "Kontak" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [terbuka, setTerbuka] = useState(false);
  const [bergulir, setBergulir] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", (v) => setBergulir(v > 24));

  const aktif = (href) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <motion.header
      initial={{ y: -90 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed inset-x-0 top-0 z-50 text-white transition-all duration-300 ${
        bergulir || terbuka
          ? "bg-ocean-950/85 py-2 shadow-lg backdrop-blur-md"
          : "bg-transparent py-4"
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-3" onClick={() => setTerbuka(false)}>
          <motion.span whileHover={{ rotate: -8, scale: 1.08 }} className="block">
            <Image src="/logo.png" alt={`Logo ${sekolah.nama}`} width={44} height={44} priority />
          </motion.span>
          <span className="font-display text-lg font-bold leading-tight">
            {sekolah.nama}
          </span>
        </Link>

        <ul className="hidden items-center gap-1 md:flex">
          {menu.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className="relative block rounded-full px-4 py-2 text-sm font-semibold text-white/90 transition-colors hover:text-white"
              >
                {aktif(item.href) && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 rounded-full bg-white/20"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span className="relative">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>

        <button
          type="button"
          aria-label="Buka menu"
          aria-expanded={terbuka}
          onClick={() => setTerbuka(!terbuka)}
          className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 rounded-lg border border-white/30 md:hidden"
        >
          <motion.span animate={terbuka ? { rotate: 45, y: 8 } : { rotate: 0, y: 0 }} className="block h-0.5 w-5 bg-white" />
          <motion.span animate={{ opacity: terbuka ? 0 : 1 }} className="block h-0.5 w-5 bg-white" />
          <motion.span animate={terbuka ? { rotate: -45, y: -8 } : { rotate: 0, y: 0 }} className="block h-0.5 w-5 bg-white" />
        </button>
      </nav>

      <AnimatePresence>
        {terbuka && (
          <motion.ul
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden px-4 md:hidden"
          >
            {menu.map((item, i) => (
              <motion.li
                key={item.href}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.05 * i }}
              >
                <Link
                  href={item.href}
                  onClick={() => setTerbuka(false)}
                  className={`block rounded-lg px-3 py-3 font-semibold ${
                    aktif(item.href) ? "text-sun" : "text-white"
                  }`}
                >
                  {item.label}
                </Link>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
