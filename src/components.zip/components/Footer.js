import Image from "next/image";
import Link from "next/link";
import { sekolah } from "@/data/sekolah";

export default function Footer() {
  return (
    <footer className="relative bg-ocean-950 text-white">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-3">
            <Image src="/logo.png" alt="" width={52} height={52} />
            <div>
              <p className="font-display text-lg font-bold">{sekolah.nama}</p>
              <p className="text-sm text-aqua-400">{sekolah.motto}</p>
            </div>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">
            {sekolah.tagline}
          </p>
        </div>

        <div>
          <h2 className="font-display text-base font-bold text-sun">Alamat</h2>
          <address className="mt-3 text-sm not-italic leading-relaxed text-white/75">
            {sekolah.alamat}
            <br />
            Telp. {sekolah.telepon}
            <br />
            {sekolah.email}
          </address>
        </div>

        <div>
          <h2 className="font-display text-base font-bold text-sun">Jelajahi</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {[
              ["/", "Home"],
              ["/about", "About"],
              ["/berita", "Berita"],
              ["/kontak", "Kontak"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="text-white/75 transition-colors hover:text-aqua-400">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-5 text-center text-sm text-white/60">
        © 2026 {sekolah.nama}. Hak cipta dilindungi.
      </div>
    </footer>
  );
}
