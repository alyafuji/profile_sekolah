"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "motion/react";

export default function BeritaCard({ berita }) {
  return (
    <motion.article
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-ocean-600/10 bg-white shadow-md shadow-ocean-900/5 hover:shadow-xl hover:shadow-ocean-900/10"
    >
      <div className="relative h-48 overflow-hidden">
        <Image
          src={berita.gambar}
          alt={berita.judul}
          width={800}
          height={450}
          unoptimized
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <span className="absolute left-3 top-3 rounded-full bg-sun px-3 py-1 text-xs font-bold text-ocean-950">
          {berita.kategori}
        </span>
        {berita.simulasi && (
          <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-ocean-800">
            Contoh
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <p className="text-sm text-ink/55">{berita.tanggal}</p>
        <h3 className="mt-1 font-display text-lg font-bold leading-snug text-ocean-900">
          {berita.judul}
        </h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/75">{berita.ringkasan}</p>

        <Link
          href={`/berita/${berita.id}`}
          className="mt-5 inline-flex items-center gap-2 self-start rounded-full bg-ocean-600 px-5 py-2.5 text-sm font-bold text-white transition-colors hover:bg-ocean-800"
        >
          Baca Selengkapnya
          <span className="transition-transform group-hover:translate-x-1">→</span>
        </Link>
      </div>
    </motion.article>
  );
}
